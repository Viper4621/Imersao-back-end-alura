//instalamos node.js para usar js fora do browser
//npn init es6 -y para criar um arquivo js versao atual
//apos declarar a variavel env camos puxar ela para testar
//npn install express usamos para instalar a framework de node.js
//comando ja cria nossa pasta node_modules e puxar o express de dentro dessa pasta
//abaixo instanciamos uma unidade do nosso server para variavel app
import express from "express";
import routes from "./src/routes/postRoutes.js";
//importamos a config do nosso mongoDB para o codigo atraves da função


//express é uma função e quando executar vai passar o resultado na variavel app ele representa nossa server
//abaixo estamos criando nosso array para consumir a api em nosso projeto
//criamos um objeto de chave e valor no caso descricao e imagem e os itens da lista
//mock = objeto falso para facilitar fluxo de desenvolvimento testando com array em memoria
//podemos printar parte do codigo e pedir para o gemini criar uma estrutura com a quantidade de objetos que desejamos
//sempre a criar uma base ou banco de dados quando criar registro precisa de um indentificador
//estrutura para guardar dados não pode ser array pois a memoria é apagada depois
//vamos usar o mongoDB que é um banco baseado em documentos é um tipo de banco de objetos mais usados em api back-end e vamos usar em
//cloud
// const posts = [
//     {
//         descricao: "Gato fazendo yoga",
//         imagem: "https://placekitten.com/400/300",
//         id: 1
//       },
//       {
//         descricao: "Gato fazendo panqueca",
//         imagem: "https://placekitten.com/400/300",
//         id: 2
//       },
//       {
//         descricao: "Gato fazendo parkour",
//         imagem: "https://placekitten.com/400/300",
//         id: 3
//       },
//       {
//         descricao: "Gato fazendo programação",
//         imagem: "https://placekitten.com/400/300",
//         id: 4
//       },
//       {
//         descricao: "Gato fazendo bigode",
//         imagem: "https://placekitten.com/400/300",
//         id: 5
//       },
//       {
//         descricao: "Gato fazendo nada",
//         imagem: "https://placekitten.com/400/300",
//         id: 6
//       },
//   ];
  //como criamos nosso objeto precisamos converter nosso array em json

const app = express();
routes(app);

//função tem 2 parametros
//função abaixa numero 3000 = porta para receber requisições pela porta 3000 esse numero geralmente é para servidor local
//e criamos a função para enviar um console.log
app.listen(3000, ()=> {
    console.log("Servidor escutando");
});
//node server.js para executar nosso servidor servidor = computador que tem recursos que alguem quer acessar se torna um server
//quando ele é capaz de receber solicitações e enviar ele se torna um servidor
//get = pegar algum recurso do servidor abaixo 2 parametros porem o 2 tem mais 2 parametros por ser uma função
// no caso função de requisição e resposta
//para derrubar servidor ctrl + c1
//200 é um codigo http siginifica ok requisição enviada e recebida com sucesso é a string é a resposta que queremos
//http.cat = status possiveis em comunicação http vão da faixa do 100 = continue / 200 = ok e derivados / 300 = redirecionamentos /
//400 = erros ou não existe não foi encontrado ou requisição feita do jeito errado
//erros 400 faixa do cliente erros 500 faixa do servidor
//em nosso get sempre usar padroes de rotas falamos de posts então criamos a rota para /posts
//agora abaixo estamos fazendo a requisão em status 200 ok pedindo a conversão em json do nosso array posts
//node --watch server.js = em vez de subir o server podemos dar watch que ele monitora em tempo real qualquer atualização
//com nosso array estamos abaixo criando nossa interface dados estão de um lado e front de outro
//neste caso estamos criando nossa api nesta rota abaixo e para acessar o array completo 



