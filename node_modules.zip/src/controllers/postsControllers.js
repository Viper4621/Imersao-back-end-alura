import getTodosPosts from "../models/postsModel.js";

export async function listarPosts(req, res) {
    //chama função para buscar todos os posts
    const posts = await getTodosPosts();
    //envia uma resposta http com status ok 200 e traz os posts em formato json
    res.status(200).json(posts);
} 
