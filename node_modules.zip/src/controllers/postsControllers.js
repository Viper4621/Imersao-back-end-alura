import getTodosPosts from "../models/postsModel.js";

export async function listarPosts(req, res) {
    //chama função para buscar todos os posts
    const posts = await getTodosPosts();
    //envia uma resposta http com status ok 200 e traz os posts em formato json
    res.status(200).json(posts);
} 

export async function postarNovoPost(req, res){
    const novoPost = req.body;
    try{
        const postCriado = await criarPost(novoPost)
        res.status(200).json(postCriado);
    }catch(erro){
        //criamos rota para post criado e o catch de erro para dar msg de erro exata
        console.error(erro.message);
    }
}