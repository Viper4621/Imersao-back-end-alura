import conectarAoBanco from "../config/dbConfig.js"

//aqui vamos dar uma função async para chamar a função de conexao e passar o parametro que salvamos no arquivo .env
const  conexao = await conectarAoBanco(process.env.STRING_CONEXAO);

export default async function getTodosPosts() {
    const db = conexao.db("imersão-instabytes");
    const colecao = db.collection("posts");
    return colecao.find().toArray();
  }