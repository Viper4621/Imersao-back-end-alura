import express from "express";
import { listarPosts, postarNovoPost  } from "../controllers/postsControllers.js";

const routes = (app) => {
      //então vamos abaixo do express informar que ele vai usar json e devolver json para as pessoas
       app.use(express.json()); 
        // rota para buscar todos os posts
       app.get("/posts", listarPosts);
       app.post("/posts", )
}

export default routes;